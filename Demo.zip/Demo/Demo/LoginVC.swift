//
//  LoginVC.swift
//  Demo
//
//  Created by Pritam Patel on 21/04/24.
//

import UIKit
import FirebaseAuth


class LoginVC: UIViewController {
    
    
    @IBOutlet weak var textPhoneNumber: UITextField!
        
    @IBOutlet weak var requestBtn: UIButton!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        requestBtn.layer.cornerRadius = 5.0
        // Do any additional setup after loading the view.
    }
    
    
    
  
    
    @IBAction func clickRequestOTpBtn(_ sender: Any) {
        
        if(loginValidation()==true){
            
            
            guard let phoneNumber = textPhoneNumber.text else { return }
    
            
            PhoneAuthProvider.provider()
              .verifyPhoneNumber(phoneNumber, uiDelegate: nil) { verificationID, error in
                  if let error = error {
                      
                      self.AlertMesaageShow(message: error.localizedDescription)
                  
                    return
                  }
                  
                  UserDefaults.standard.set(verificationID, forKey: "verificationID")
                  UserDefaults.standard.set(phoneNumber, forKey: "phoneNumber")
                  let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                  let newViewController = storyBoard.instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
                  self.present(newViewController, animated: true, completion: nil)
                                      
              }
            
            
        }

        
        
        
    }
    
    
    
    func loginValidation() -> Bool {
        let phone_number : String  = textPhoneNumber.text!

        print("phone_number: \(String(describing: phone_number))")
        
        if (phone_number.isEmpty == true) {
            let alert_message: String  = "Dear user, please enter phone number."
            AlertMesaageShow(message: alert_message)
           return false
        }else{
            
        }
        
        
       return true
        
    }
    
    func AlertMesaageShow(message: String){
        DispatchQueue.main.async {
        let alert = UIAlertController(title: "Alert!", message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        }
    }


    

}
