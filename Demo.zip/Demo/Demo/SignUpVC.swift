//
//  SignUpVC.swift
//  Demo
//
//  Created by Pritam Patel on 21/04/24.
//

import UIKit
import FirebaseAuth


class SignUpVC: UIViewController {
    
    
    
    @IBOutlet weak var textOtp: UITextField!
    
    
    @IBOutlet weak var verifyBtn: UIButton!
    
    @IBOutlet weak var resendOtpBtn: UIButton!
    
    var phoneNumber: String = String()
    var verificationID: String = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        verifyBtn.layer.cornerRadius = 5.0
        resendOtpBtn.layer.cornerRadius = 5.0
        
        verificationID = UserDefaults.standard.string(forKey: "verificationID")!
        phoneNumber = UserDefaults.standard.string(forKey: "phoneNumber")!
    }
    
    
    @IBAction func clickBackBtn(_ sender: Any) {
        
        dismiss(animated: true)
        
    }
   
    
    @IBAction func clickVerifyOTp(_ sender: Any) {
        
        
        
        let verificationCode = textOtp.text!
       
        let credential = PhoneAuthProvider.provider().credential(
          withVerificationID: verificationID,
          verificationCode: verificationCode
        )
        
        Auth.auth().signIn(with: credential) { authResult, error in
            if let error = error {
              let authError = error as NSError
              
              return
            }
            // User is signed in
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let newViewController = storyBoard.instantiateViewController(withIdentifier: "UploadImageDetailsVC") as! UploadImageDetailsVC
            self.present(newViewController, animated: true, completion: nil)
        }
        
        
        
    }
    
    
    @IBAction func clickresendOtpBtn(_ sender: Any) {
        

       
        
        PhoneAuthProvider.provider().verifyPhoneNumber(phoneNumber, uiDelegate: nil) { (verificationID, error) in
            if let error = error {
                print("Error sending verification code: \(error.localizedDescription)")
                // Handle error
                return
            }
            
            // Verification code successfully sent
            print("Verification code sent successfully")
            showToast(controller:self,message: "Verification code sent successfully.", seconds: 2.0)
            UserDefaults.standard.set(verificationID, forKey: "verificationID")
        }
        
        
    }
    
   
    
    
    func signUpValidation() -> Bool {
       
        let otp : String  = textOtp.text!

        
        if  otp.isEmpty == true {
            let alert_message: String  = "Dear user, please enter otp."
           AlertMesaageShow(message: alert_message)
           return false
        }
        
   
        
       return true
        
    }
    
    func AlertMesaageShow(message: String){
        DispatchQueue.main.async {
        let alert = UIAlertController(title: "Alert!", message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        }
    }
    


    
    
}
