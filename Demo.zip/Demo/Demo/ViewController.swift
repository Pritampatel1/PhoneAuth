//
//  ViewController.swift
//  Demo
//
//  Created by Pritam Patel on 21/04/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var loginBtn: UIButton!
    
    @IBOutlet weak var signUpBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        loginBtn.layer.cornerRadius = 5.0
        signUpBtn.layer.cornerRadius = 5.0
    }

    @IBAction func clickLoginBtn(_ sender: Any) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        self.present(newViewController, animated: true, completion: nil)

        
    }
    
    @IBAction func clickSighUpBtn(_ sender: Any) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
        self.present(newViewController, animated: true, completion: nil)

        
    }
}

