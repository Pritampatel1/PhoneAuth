

import Foundation
class ImageDetailReportList {
    
    var imageUrls :  String?
    var postCreationDate :  String?
    var userId :  String?
    var postDescription :  String?
    
 
 
}
