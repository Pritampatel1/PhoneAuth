//
//  UploadImageDetailsVC.swift
//  Demo
//
//  Created by Pritam Patel on 22/04/24.
//

import UIKit
import FirebaseAuth
import Firebase
import FirebaseStorage
import FirebaseDatabase

class UploadImageDetailsVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var showImage: UIImageView!
    @IBOutlet weak var textRemarks: UITextField!
    @IBOutlet weak var tblVieww: UITableView!
    @IBOutlet weak var uploadImageBtn: UIButton!
    @IBOutlet weak var saveBtn: UIButton!
    
    var imagPickUp : UIImagePickerController!
    var activityIndicator = UIActivityIndicatorView()
    var image_url : String = String()

    var imageUrls: [URL] = []
    var imageListItems = [ImageDetailReportList]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        tblVieww.delegate = self
        tblVieww.dataSource = self
      
        imagPickUp = self.imageAndVideos()
        uploadImageBtn.layer.cornerRadius = 5.0
        saveBtn.layer.cornerRadius = 5.0


        activityIndicator =  UIActivityIndicatorView(style: .large)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 200, height: 200)
        activityIndicator.center = view.center
        activityIndicator.isHidden = true
        self.view.addSubview(activityIndicator)
        
//        GetImageDetailsFromFirebase()
    }
   
    
    
    @IBAction func clickUploadImageBtn(_ sender: Any) {
        
        Takeimage()
    }
    
    @IBAction func clickSaveBtn(_ sender: Any) {
        
        
        
        if(loginValidation()==true){
            
            imageDetailInFirebase()
        }
        
        
        
    }
    
    
    @IBAction func clickLogOutBtn(_ sender: Any) {
        
        
        let firebaseAuth = Auth.auth()
        do {
          try firebaseAuth.signOut()
            
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let newViewController = storyBoard.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            self.present(newViewController, animated: true, completion: nil)
            
        } catch let signOutError as NSError {
          print("Error signing out: %@", signOutError)
        }
        
        
    }
    
    
    func Takeimage(){
        print("Takeimage")
        DispatchQueue.main.async {
        let ActionSheet = UIAlertController(title: nil, message: "Select Photo", preferredStyle: .actionSheet)

            let cameraPhoto = UIAlertAction(title: "Camera", style: .default, handler: {
                (alert: UIAlertAction) -> Void in
                if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera){
                    self.imagPickUp.mediaTypes = ["public.image"]
                    self.imagPickUp.sourceType = UIImagePickerController.SourceType.camera;
                    self.present(self.imagPickUp, animated: true, completion: nil)
                    print("camera_photo")
                }
                else{
                    UIAlertController(title: "dayTrack", message: "No Camera available.", preferredStyle: .alert).show(self, sender: nil);
                }

            })

            let PhotoLibrary = UIAlertAction(title: "Photo Library", style: .default, handler: {
                (alert: UIAlertAction) -> Void in
                if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.photoLibrary){
                    self.imagPickUp.mediaTypes = ["public.image"]
                    self.imagPickUp.sourceType = UIImagePickerController.SourceType.photoLibrary;
                    self.present(self.imagPickUp, animated: true, completion: nil)
                    print("Library_photo")
                }

            })

            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: {
                (alert: UIAlertAction) -> Void in

            })

            ActionSheet.addAction(cameraPhoto)
            ActionSheet.addAction(PhotoLibrary)
            ActionSheet.addAction(cancelAction)


            if UIDevice.current.userInterfaceIdiom == .pad{
                let presentC : UIPopoverPresentationController  = ActionSheet.popoverPresentationController!
                presentC.sourceView = self.view
                presentC.sourceRect = self.view.bounds
                self.present(ActionSheet, animated: true, completion: nil)
            }
            else{
                self.present(ActionSheet, animated: true, completion: nil)
            }
        }
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        print("image_path: \(String(describing: image))")
        showImage.image = image
        uploadImage(image!)
        
        
        
    print("image_successs")
        imagPickUp.dismiss(animated: true, completion: { () -> Void in
            // Dismiss
        })

    }

    func uploadImage(_ image: UIImage) {
        activityIndicator.startAnimating()
        let currentDate = getCurrentDatetime()
        let userId = UUID().uuidString
        print("User ID: \(userId)")

        let storageRef = Storage.storage().reference().child("Image").child(userId)
        let imageData = image.lowestQualityJPEGNSData
        guard image.pngData() != nil else{
            return
        }
        
            storageRef.putData(imageData, metadata: nil
                , completion: { (metadata, error) in
                    if error != nil {
                        print("error")
                        self.activityIndicator.stopAnimating()
                        self.AlertMesaageShow(message: "Please try again later")
                        self.activityIndicator.stopAnimating()
                        return
                    }else{
                        self.activityIndicator.stopAnimating()
                    }
                    
                
                storageRef.downloadURL { (url, error) in
                        if let error = error  {
                          print("Error on getting download url: \(error.localizedDescription)")
                            self.activityIndicator.stopAnimating()
                          return
                        }
                    self.image_url = url!.absoluteString
                    print("Download url of is==: \(url!.absoluteString)")
                    self.activityIndicator.stopAnimating()
                    showToast(controller:self,message: "Image has been uploaded successfully.", seconds: 2.0)
                      }

            })
            
        
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        imagPickUp.dismiss(animated: true, completion: { () -> Void in
            // Dismiss
        })
    }
    func imageAndVideos()-> UIImagePickerController{
        if(imagPickUp == nil){
            imagPickUp = UIImagePickerController()
            imagPickUp.delegate = self
            imagPickUp.allowsEditing = false
        }
        return imagPickUp
    }
 

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return imageListItems.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "UploadImageDetailsTblViwCell", for: indexPath) as! UploadImageDetailsTblViwCell
     
            
            let imageUrl = imageListItems[indexPath.row].imageUrls
            
            let imageUrlString = imageUrl!
                 if let imageUrl = URL(string: imageUrlString) {
                     let session = URLSession(configuration: .default)
                    
                     let task = session.dataTask(with: imageUrl) { (data, response, error) in

                         if let error = error {
                             print("Error fetching image: \(error)")
                             
                             return
                         }
                        
                         if let imageData = data {
                             
                             if let image = UIImage(data: imageData) {
                                
                                 DispatchQueue.main.async {
                                   
                                     cell.ImageShow.image = image
                                 }
                             } else {
                                 print("Error creating image from data")
                             }
                         } else {
                             print("No image data")
                         }
                     }
                   
                     task.resume()
                 } else {
                     print("Invalid URL")
                 }
            
            
            
            return cell
        }
    
   
    
    func imageDetailInFirebase() {
        
     
        
        var user_id : String = UUID().uuidString
        let currentDate = getCurrentDatetime()
        
       
        let description = textRemarks.text ?? ""
        var ref: DatabaseReference!
        ref = Database.database().reference()
        
        ref.child("ImageDetails").child(user_id).setValue(
           ["imageUrls":image_url,"postCreationDate":currentDate,"userId":user_id,"postDescription":description])
        let alert_message: String  = "Details submit successfully."
        AlertMesaagesuccess(message: alert_message)
    }
    func AlertMesaagesuccess(message: String){
        DispatchQueue.main.async {
        let alert = UIAlertController(title: "Alert!", message: message, preferredStyle: UIAlertController.Style.alert)
        // add an action (button)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            
            self.GetImageDetailsFromFirebase()
            
            self.textRemarks.text = ""
            self.showImage.image = UIImage(named: "")
            
//            self.dismiss(animated: true)
        // show the alert
        self.present(alert, animated: true, completion: nil)
        }
    }
    
    
    func GetImageDetailsFromFirebase(){
        imageListItems.removeAll()
        var ref: DatabaseReference!
        ref = Database.database().reference()
       
        ref.child("ImageDetails").observeSingleEvent(of: .value, with: { snapshot in
          // Get user value
         
            print("snapshotsnapshotsas===: \(String(describing: snapshot)))")
            if(snapshot != nil){
                for child in snapshot.children {
                    let model = ImageDetailReportList()
                    
                    let snap = child as! DataSnapshot
                    print("snapsnapsnapssa===: \(String(describing: snap)))")
                    
                    let snap_data = snap.value as! [String: Any]
                    
                    print("snap_dataxs===: \(String(describing: snap_data)))")
                    
                    let imageUrls = snap_data["imageUrls"] as? String ?? ""
                    model.imageUrls = imageUrls as? String
                    print("imageUrls===: \(String(describing: imageUrls)))")
                    
                   
                    let postCreationDate = snap_data["postCreationDate"] as? String ?? ""
                    model.postCreationDate = postCreationDate as? String
                    print("postCreationDate===: \(String(describing: postCreationDate)))")
                    
                    let userId = snap_data["userId"] as? String ?? ""
                    model.userId = userId as? String
                    print("userId===: \(String(describing: userId)))")
                    
                    
                    let postDescription = snap_data["postDescription"] as? String ?? ""
                    model.postDescription = postDescription as? String
                    print("postDescription===: \(String(describing: postDescription)))")
                    
                    self.imageListItems.append(model)
           
                }
                OperationQueue.main.addOperation ({
                   
                    self.tblVieww.delegate = self
                    self.tblVieww.dataSource = self
                    self.activityIndicator.stopAnimating()
                    self.tblVieww.reloadData()
                    NSLog("adddd","")
                })
                
            }else{
               
            }
        }) { error in
          print(error.localizedDescription)
            print("localizedDescription===: \(String(describing: error.localizedDescription)))")
        }
    }
    
    
    
    
    
    func loginValidation() -> Bool {
        
      
        let description : String  = textRemarks.text!

        if (image_url.isEmpty == true) {
            let alert_message: String  = "Dear user, please select image."
            AlertMesaageShow(message: alert_message)
           return false
        }else{
            
        }
        
        if (description.isEmpty == true) {
            let alert_message: String  = "Dear user, please enter remarks."
            AlertMesaageShow(message: alert_message)
           return false
        }else{
            
        }

       return true
        
    }
    
    func AlertMesaageShow(message: String){
        DispatchQueue.main.async {
        let alert = UIAlertController(title: "Alert!", message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        }
    }

    
    
  
    
}

